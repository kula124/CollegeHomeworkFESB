#ifndef FUNKCIJE_H
#define FUNKCIJE_H
int rw(int fdin, int fdout);
#endif