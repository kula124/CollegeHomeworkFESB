#ifndef FUNKCIJE_H
#define FUNKCIJE_H
void Pozdrav();
#endif
