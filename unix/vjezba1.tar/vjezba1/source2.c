#include "funkcije.h"

int main()
{
	Pozdrav();
	return 0;
}
