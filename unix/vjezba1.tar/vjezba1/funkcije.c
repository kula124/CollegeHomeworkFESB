#include <stdio.h>
void Pozdrav()
{
  printf("Hello world\n");
}
